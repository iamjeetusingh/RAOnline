<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple PHP Web Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to My Web Page - by JEETU</h1>
        <p>
            <?php
                date_default_timezone_set("Asia/Kolkata");
                $hour = date("H");
                if ($hour < 12) {
                    echo "Good morning!";
                } elseif ($hour < 18) {
                    echo "Good afternoon!";
                } else {
                    echo "Good evening!";
                }
            ?>
        </p>
        <p>Current Date & Time: <?php echo date("d M Y, h:i A"); ?></p>
    </div>
</body>
</html>
